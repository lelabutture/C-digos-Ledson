let n = 1;


//   while (true){
//     let n2 = (Math.random() *
//               60).toFixed (2);
//   console.log(n2);
//   console.clear();
// }
// while(n <= 10) { // loop infinito
//             //CTRL + C para parar/ INTERROMPER
//   console.log(n);
//   n++;
// }

// WHILE VS DO WHILE
 // do {
 //   console.log("----MENU----");
 //   console.log("Qual é seu nome?");
 //   console.log("---------------");
 //  // n += 1
 //  //n++  opções de n++
 //   n = n + 1
 // } while (n > 10)

/** DESAFIO 01 */

//1) CRIE UM LOOP QUE RODE
// ENQUANTO O USUÁRIO NÃO ESTIVER LOGADO
// VERIFIQUE USUÁRIO E SENHA
// SE OS DADOS ESTIVEREM ERRADOS:
// INFORME O ERRO